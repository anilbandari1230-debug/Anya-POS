import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";

export type Role = "cashier" | "kitchen" | null;

export type StaffUser = {
  id: string;
  name: string;
  pinHash: string;
  role: "cashier" | "kitchen";
};

type AuthCtx = {
  role: Role;
  userName: string | null;
  signIn: (pin: string) => Promise<{ role: "cashier" | "kitchen"; name: string } | null>;
  signOut: () => void;
};

const Ctx = createContext<AuthCtx | null>(null);
const ROLE_KEY = "pos_role";
const USER_KEY = "pos_user";

export async function hashPin(pin: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(pin));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function pinMatches(entered: string, stored: string): Promise<boolean> {
  if (stored.length === 64 && /^[0-9a-f]+$/.test(stored)) {
    return (await hashPin(entered)) === stored;
  }
  return entered === stored; // legacy plaintext fallback
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<Role>(null);
  const [userName, setUserName] = useState<string | null>(null);

  useEffect(() => {
    const storedRole = typeof window !== "undefined" ? localStorage.getItem(ROLE_KEY) : null;
    const storedUser = typeof window !== "undefined" ? localStorage.getItem(USER_KEY) : null;
    if (storedRole === "cashier" || storedRole === "kitchen") {
      setRole(storedRole);
      setUserName(storedUser);
    }
  }, []);

  const signIn = async (pin: string): Promise<{ role: "cashier" | "kitchen"; name: string } | null> => {
    // 1. Try named staff list
    const { data: staffData } = await supabase.from("settings").select("value").eq("key", "staff").maybeSingle();
    const staffList = (staffData?.value ?? []) as StaffUser[];
    for (const user of staffList) {
      if (await pinMatches(pin, user.pinHash)) {
        localStorage.setItem(ROLE_KEY, user.role);
        localStorage.setItem(USER_KEY, user.name);
        setRole(user.role);
        setUserName(user.name);
        return { role: user.role, name: user.name };
      }
    }

    // 2. Legacy global cashier/kitchen PINs fallback
    const { data: pinsData } = await supabase.from("settings").select("value").eq("key", "pins").maybeSingle();
    const v = (pinsData?.value ?? {}) as { cashier?: string; kitchen?: string };
    const legacyPins = { cashier: v.cashier ?? "1234", kitchen: v.kitchen ?? "5678" };
    let legacyRole: "cashier" | "kitchen" | null = null;
    if (await pinMatches(pin, legacyPins.cashier)) legacyRole = "cashier";
    else if (await pinMatches(pin, legacyPins.kitchen)) legacyRole = "kitchen";
    if (legacyRole) {
      const name = legacyRole === "cashier" ? "Cashier" : "Kitchen";
      localStorage.setItem(ROLE_KEY, legacyRole);
      localStorage.setItem(USER_KEY, name);
      setRole(legacyRole);
      setUserName(name);
      return { role: legacyRole, name };
    }

    return null;
  };

  const signOut = () => {
    localStorage.removeItem(ROLE_KEY);
    localStorage.removeItem(USER_KEY);
    setRole(null);
    setUserName(null);
  };

  return <Ctx.Provider value={{ role, userName, signIn, signOut }}>{children}</Ctx.Provider>;
}

export const useAuth = () => {
  const c = useContext(Ctx);
  if (!c) throw new Error("AuthProvider missing");
  return c;
};
