/** Request browser notification permission. Call once on app load. */
export function requestNotificationPermission(): void {
  if (typeof window === "undefined" || !("Notification" in window)) return;
  if (Notification.permission === "default") {
    Notification.requestPermission();
  }
}

/** Fire a browser notification if permission is granted. */
export function sendNotification(title: string, body: string): void {
  if (typeof window === "undefined" || !("Notification" in window)) return;
  if (Notification.permission !== "granted") return;
  try {
    new Notification(title, { body, icon: "/logo.png", badge: "/logo.png" });
  } catch {
    // Some environments (e.g. Firefox private mode) block even granted notifications
  }
}
