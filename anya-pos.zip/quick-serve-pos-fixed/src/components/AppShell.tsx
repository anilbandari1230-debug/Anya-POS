import { Link, useRouterState } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth";
import { useEffect } from "react";
import { LayoutGrid, ChefHat, Settings, BarChart3, BookOpen, LogOut, ClipboardList } from "lucide-react";
import { requestNotificationPermission } from "@/lib/notifications";
import type { ReactNode } from "react";

type NavItem = { to: string; label: string; icon: typeof LayoutGrid; exact?: boolean };
const cashierNav: NavItem[] = [
  { to: "/", label: "POS", icon: LayoutGrid, exact: true },
  { to: "/admin", label: "Menu", icon: BookOpen },
  { to: "/orders", label: "Orders", icon: ClipboardList },
  { to: "/reports", label: "Reports", icon: BarChart3 },
  { to: "/settings", label: "Settings", icon: Settings },
];
const kitchenNav: NavItem[] = [{ to: "/kitchen", label: "Kitchen", icon: ChefHat, exact: true }];

export function AppShell({ children }: { children: ReactNode }) {
  const { role, userName, signOut } = useAuth();
  const path = useRouterState({ select: (s) => s.location.pathname });
  const nav = role === "kitchen" ? kitchenNav : cashierNav;

  useEffect(() => {
    requestNotificationPermission();
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <header className="surface border-b sticky top-0 z-30">
        <div className="flex items-center gap-1 px-3 h-14">
          {/* Logo */}
          <div className="flex items-center gap-2 mr-3 shrink-0">
            <img src="/logo.png" alt="ANYA" className="h-9 w-9 rounded-lg object-cover" />
            <span className="font-bold tracking-tight hidden sm:inline text-base">ANYA</span>
          </div>

          <nav className="flex items-center gap-1 overflow-x-auto flex-1 min-w-0">
            {nav.map((n) => {
              const active = n.exact ? path === n.to : path.startsWith(n.to);
              const Icon = n.icon;
              return (
                <Link
                  key={n.to} to={n.to as string}
                  className={`flex items-center gap-2 px-3 h-10 rounded-lg text-sm font-medium transition shrink-0 ${active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-secondary hover:text-foreground"}`}
                >
                  <Icon className="h-4 w-4" />
                  <span className="hidden sm:inline">{n.label}</span>
                </Link>
              );
            })}
          </nav>

          <div className="ml-auto flex items-center gap-2 shrink-0">
            {userName && (
              <span className="text-xs px-2 py-1 rounded-md bg-secondary text-secondary-foreground hidden sm:inline truncate max-w-[100px]">
                {userName}
              </span>
            )}
            <button
              onClick={signOut}
              className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground px-2 h-10"
            >
              <LogOut className="h-4 w-4" />
              <span className="hidden sm:inline">Sign out</span>
            </button>
          </div>
        </div>
      </header>
      <main className="flex-1 min-h-0">{children}</main>
    </div>
  );
}
