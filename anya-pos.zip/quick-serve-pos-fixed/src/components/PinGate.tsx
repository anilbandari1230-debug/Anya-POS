import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { Delete } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "@tanstack/react-router";

export function PinGate({ children, require }: { children: React.ReactNode; require?: "cashier" | "kitchen" }) {
  const { role } = useAuth();
  if (!role) return <PinScreen />;
  if (require && role !== require) return <PinScreen wrongRole={role} need={require} />;
  return <>{children}</>;
}

function PinScreen({ wrongRole, need }: { wrongRole?: string; need?: string }) {
  const { signIn, signOut } = useAuth();
  const navigate = useNavigate();
  const [pin, setPin] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (next: string) => {
    setBusy(true);
    const result = await signIn(next);
    setBusy(false);
    if (!result) {
      toast.error("Invalid PIN");
      setPin("");
    } else {
      toast.success(`Welcome, ${result.name}!`);
      navigate({ to: result.role === "kitchen" ? "/kitchen" : "/" });
    }
  };

  const tap = (d: string) => {
    if (busy) return;
    if (d === "←") return setPin((p) => p.slice(0, -1));
    if (d === "C") return setPin("");
    setPin((p) => {
      const next = (p + d).slice(0, 6);
      if (next.length >= 4) submit(next);
      return next;
    });
  };

  return (
    <div className="min-h-screen grid place-items-center px-4 bg-background">
      <div className="w-full max-w-sm surface rounded-2xl shadow-pop p-8">
        <div className="flex flex-col items-center gap-2 mb-6">
          {/* ANYA Logo */}
          <img src="/logo.png" alt="ANYA POS" className="h-24 w-24 rounded-2xl object-cover shadow-soft" />
          <h1 className="text-2xl font-semibold tracking-tight mt-1">ANYA POS</h1>
          <p className="text-sm text-muted-foreground">Enter your PIN to continue</p>
          {wrongRole && need && (
            <p className="text-xs text-destructive mt-1 text-center">
              Signed in as {wrongRole}. Sign out to access {need}.
            </p>
          )}
        </div>

        <div className="flex justify-center gap-3 mb-6">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className={`h-4 w-4 rounded-full border-2 transition-colors ${pin.length > i ? "bg-primary border-primary" : "border-border"}`} />
          ))}
        </div>

        <div className="grid grid-cols-3 gap-3">
          {["1","2","3","4","5","6","7","8","9","C","0","←"].map((d) => (
            <button
              key={d} onClick={() => tap(d)}
              className="h-16 rounded-xl bg-secondary text-secondary-foreground text-xl font-medium hover:bg-muted active:scale-95 transition tap shadow-soft grid place-items-center"
            >
              {d === "←" ? <Delete className="h-5 w-5" /> : d}
            </button>
          ))}
        </div>

        {wrongRole && (
          <button onClick={signOut} className="mt-6 w-full text-sm text-muted-foreground hover:text-foreground text-center">
            Sign out
          </button>
        )}
      </div>
    </div>
  );
}
