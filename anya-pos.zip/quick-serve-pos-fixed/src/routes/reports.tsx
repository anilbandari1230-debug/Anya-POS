import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PinGate } from "@/components/PinGate";
import { AppShell } from "@/components/AppShell";
import { fmt } from "@/lib/format";
import { BarChart3, IndianRupee, ShoppingBag, TrendingUp } from "lucide-react";

export const Route = createFileRoute("/reports")({
  component: () => (
    <PinGate require="cashier">
      <AppShell><Reports /></AppShell>
    </PinGate>
  ),
});

type O = { id: string; total: number; subtotal: number; tax: number; payment_method: string | null; billed_at: string | null; created_at: string; table_name: string | null };
type Oi = { name: string; qty: number; price: number; order_id: string };

function Reports() {
  const [orders, setOrders] = useState<O[]>([]);
  const [items, setItems] = useState<Oi[]>([]);
  const [range, setRange] = useState<"day" | "week" | "month">("day");
  const [currency, setCurrency] = useState("₹");

  useEffect(() => {
    supabase.from("settings").select("value").eq("key", "restaurant").maybeSingle().then(({ data }) => {
      const v = (data?.value ?? {}) as { currency?: string };
      setCurrency(v.currency ?? "₹");
    });
  }, []);

  useEffect(() => {
    // BUG-006 fix: compute range boundaries in UTC to match Supabase's UTC-stored billed_at
    const now = new Date();
    let since: Date;
    if (range === "day") {
      // UTC midnight of today
      since = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
    } else if (range === "week") {
      since = new Date(now);
      since.setUTCDate(since.getUTCDate() - 7);
    } else {
      since = new Date(now);
      since.setUTCMonth(since.getUTCMonth() - 1);
    }
    supabase
      .from("orders")
      .select("*")
      .eq("status", "billed")
      .gte("billed_at", since.toISOString())
      .then(({ data }) => {
        const list = (data ?? []) as O[];
        setOrders(list);
        if (list.length) {
          supabase.from("order_items").select("name,qty,price,order_id,status").in("order_id", list.map((o) => o.id))
            .then(({ data: oi }) => setItems(((oi ?? []) as (Oi & { status: string })[]).filter((x) => x.status !== "rejected")));
        } else setItems([]);
      });
  }, [range]);

  const total = orders.reduce((s, o) => s + Number(o.total), 0);
  const cash = orders.filter((o) => o.payment_method === "cash").reduce((s, o) => s + Number(o.total), 0);
  const upi = orders.filter((o) => o.payment_method === "upi").reduce((s, o) => s + Number(o.total), 0);
  const card = orders.filter((o) => o.payment_method === "card").reduce((s, o) => s + Number(o.total), 0);

  const itemMap = new Map<string, { qty: number; revenue: number }>();
  items.forEach((i) => {
    const cur = itemMap.get(i.name) ?? { qty: 0, revenue: 0 };
    cur.qty += i.qty;
    cur.revenue += Number(i.price) * i.qty;
    itemMap.set(i.name, cur);
  });
  const topItems = [...itemMap.entries()].sort((a, b) => b[1].qty - a[1].qty).slice(0, 8);

  const byTable = new Map<string, number>();
  orders.forEach((o) => byTable.set(o.table_name ?? "—", (byTable.get(o.table_name ?? "—") ?? 0) + Number(o.total)));
  const tableRows = [...byTable.entries()].sort((a, b) => b[1] - a[1]);

  return (
    <div className="p-4 max-w-6xl mx-auto">
      <div className="flex items-center gap-2 mb-1">
        <BarChart3 className="h-5 w-5" />
        <h1 className="text-2xl font-semibold tracking-tight">Reports</h1>
      </div>
      <p className="text-sm text-muted-foreground mb-4">Sales summary across periods.</p>

      <div className="flex gap-2 mb-4">
        {(["day", "week", "month"] as const).map((r) => (
          <button key={r} onClick={() => setRange(r)} className={`h-9 px-4 rounded-lg text-sm font-medium capitalize ${range === r ? "bg-foreground text-background" : "bg-secondary"}`}>
            {r === "day" ? "Today" : r === "week" ? "Last 7 days" : "Last 30 days"}
          </button>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        <Stat icon={IndianRupee} label="Revenue" value={fmt(total, currency)} />
        <Stat icon={ShoppingBag} label="Orders" value={String(orders.length)} />
        <Stat icon={TrendingUp} label="Avg ticket" value={fmt(orders.length ? total / orders.length : 0, currency)} />
        <Stat icon={IndianRupee} label="UPI vs Cash" value={`${fmt(upi, currency)} / ${fmt(cash, currency)}`} />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="surface rounded-2xl border p-4">
          <h2 className="font-semibold mb-3">Top selling items</h2>
          <div className="space-y-2">
            {topItems.map(([name, v]) => (
              <div key={name} className="flex items-center justify-between text-sm">
                <span className="truncate">{name}</span>
                <span className="text-muted-foreground">×{v.qty} · {fmt(v.revenue, currency)}</span>
              </div>
            ))}
            {!topItems.length && <div className="text-sm text-muted-foreground">No data yet.</div>}
          </div>
        </div>
        <div className="surface rounded-2xl border p-4">
          <h2 className="font-semibold mb-3">Sales by table</h2>
          <div className="space-y-2">
            {tableRows.map(([name, v]) => (
              <div key={name} className="flex items-center justify-between text-sm">
                <span>{name}</span><span className="text-muted-foreground">{fmt(v, currency)}</span>
              </div>
            ))}
            {!tableRows.length && <div className="text-sm text-muted-foreground">No data yet.</div>}
          </div>
        </div>
        <div className="surface rounded-2xl border p-4 lg:col-span-2">
          <h2 className="font-semibold mb-3">Payment breakdown</h2>
          <div className="grid grid-cols-3 gap-3 text-center">
            <PayStat label="Cash" value={fmt(cash, currency)} />
            <PayStat label="UPI" value={fmt(upi, currency)} />
            <PayStat label="Card" value={fmt(card, currency)} />
          </div>
        </div>
      </div>
    </div>
  );
}

function Stat({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string }) {
  return (
    <div className="surface rounded-2xl border p-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground"><Icon className="h-4 w-4" /> {label}</div>
      <div className="text-2xl font-semibold mt-1 tracking-tight">{value}</div>
    </div>
  );
}
function PayStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-secondary p-4">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="text-lg font-semibold">{value}</div>
    </div>
  );
}
