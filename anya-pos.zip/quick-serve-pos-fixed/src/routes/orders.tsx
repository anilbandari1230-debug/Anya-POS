import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PinGate } from "@/components/PinGate";
import { AppShell } from "@/components/AppShell";
import { fmt, dt } from "@/lib/format";
import { ClipboardList, ChevronDown, ChevronUp, Search, Download, Pencil, X, Save } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/orders")({
  component: () => (
    <PinGate require="cashier">
      <AppShell><OrdersScreen /></AppShell>
    </PinGate>
  ),
});

type Order = {
  id: string;
  bill_number: number;
  table_name: string | null;
  status: string;
  subtotal: number;
  tax: number;
  total: number;
  payment_method: string | null;
  notes: string | null;
  billed_at: string | null;
  created_at: string;
};
type OrderItem = { id: string; name: string; qty: number; price: number; status: string };

// ── CSV / Excel export ────────────────────────────────────────────────────────
function escapeCell(v: string | number | null | undefined): string {
  const s = String(v ?? "");
  if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

async function exportToExcel(
  filtered: Order[],
  loadedItems: Record<string, OrderItem[]>,
  currency: string
) {
  const missing = filtered.map((o) => o.id).filter((id) => !loadedItems[id]);
  const fetchedItems: Record<string, OrderItem[]> = {};
  if (missing.length) {
    const { data } = await supabase.from("order_items").select("*").in("order_id", missing);
    (data ?? []).forEach((row: any) => {
      (fetchedItems[row.order_id] ??= []).push(row as OrderItem);
    });
  }
  const items = { ...loadedItems, ...fetchedItems };

  const headers = [
    "Bill #", "Date", "Time", "Table",
    "Item", "Qty", "Rate", "Item Amount",
    "Subtotal", "Tax", "Total", "Payment", "Notes",
  ];

  const rows: string[][] = [];
  for (const o of filtered) {
    const d = o.billed_at ? new Date(o.billed_at) : null;
    const date = d ? d.toLocaleDateString("en-IN") : "";
    const time = d ? d.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }) : "";
    const orderItems = (items[o.id] ?? []).filter((i) => i.status !== "rejected");

    if (!orderItems.length) {
      rows.push([String(o.bill_number), date, time, o.table_name ?? "",
        "", "", "", "",
        Number(o.subtotal).toFixed(2), Number(o.tax).toFixed(2), Number(o.total).toFixed(2),
        o.payment_method ?? "", o.notes ?? ""]);
    } else {
      orderItems.forEach((item, idx) => {
        rows.push([
          String(o.bill_number), date, time, o.table_name ?? "",
          item.name, String(item.qty),
          Number(item.price).toFixed(2),
          (Number(item.price) * item.qty).toFixed(2),
          idx === 0 ? Number(o.subtotal).toFixed(2) : "",
          idx === 0 ? Number(o.tax).toFixed(2) : "",
          idx === 0 ? Number(o.total).toFixed(2) : "",
          idx === 0 ? (o.payment_method ?? "") : "",
          idx === 0 ? (o.notes ?? "") : "",
        ]);
      });
    }
  }

  const csv = [headers.map(escapeCell).join(","), ...rows.map((r) => r.map(escapeCell).join(","))].join("\r\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `orders-${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// ── Edit Modal ────────────────────────────────────────────────────────────────
function EditOrderModal({ order, currency, onClose, onSaved }: {
  order: Order; currency: string;
  onClose: () => void; onSaved: (updated: Order) => void;
}) {
  const [method, setMethod] = useState(order.payment_method ?? "cash");
  const [notes, setNotes] = useState(order.notes ?? "");
  const [tableName, setTableName] = useState(order.table_name ?? "");
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    const patch = {
      payment_method: method as "cash" | "upi" | "card" | "other",
      notes: notes.trim() || null,
      table_name: tableName.trim() || null,
    };
    const { error } = await supabase.from("orders").update(patch).eq("id", order.id);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Order updated");
    onSaved({ ...order, ...patch });
  };

  return (
    <div className="fixed inset-0 z-50 bg-foreground/50 grid place-items-center p-4" onClick={onClose}>
      <div className="surface rounded-2xl shadow-pop w-full max-w-md" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between p-5 border-b">
          <div>
            <div className="font-semibold">Edit Order #{order.bill_number}</div>
            <div className="text-xs text-muted-foreground mt-0.5">{dt(order.billed_at)}</div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-secondary"><X className="h-4 w-4" /></button>
        </div>

        <div className="p-5 space-y-4">
          <div className="rounded-xl bg-secondary/40 px-4 py-3 grid grid-cols-3 text-center text-sm">
            <div><div className="text-xs text-muted-foreground">Subtotal</div><div className="font-medium">{fmt(order.subtotal, currency)}</div></div>
            <div><div className="text-xs text-muted-foreground">Tax</div><div className="font-medium">{fmt(order.tax, currency)}</div></div>
            <div><div className="text-xs text-muted-foreground">Total</div><div className="font-semibold">{fmt(order.total, currency)}</div></div>
          </div>

          <div>
            <label className="text-xs text-muted-foreground block mb-1">Table name</label>
            <input value={tableName} onChange={(e) => setTableName(e.target.value)}
              className="h-11 w-full px-3 rounded-lg bg-background border text-sm" placeholder="e.g. Table 3" />
          </div>

          <div>
            <label className="text-xs text-muted-foreground block mb-2">Payment method</label>
            <div className="grid grid-cols-3 gap-2">
              {(["cash", "upi", "card"] as const).map((m) => (
                <button key={m} onClick={() => setMethod(m)}
                  className={`h-11 rounded-xl border-2 text-sm font-medium uppercase transition ${method === m ? "border-primary bg-primary/5 text-primary" : "border-border bg-card"}`}>
                  {m}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs text-muted-foreground block mb-1">Notes</label>
            <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2}
              placeholder="Any notes about this order…"
              className="w-full px-3 py-2 rounded-lg bg-background border text-sm resize-none" />
          </div>
        </div>

        <div className="p-5 border-t flex gap-2">
          <button onClick={onClose} className="flex-1 h-11 rounded-xl bg-secondary font-medium text-sm">Cancel</button>
          <button onClick={save} disabled={saving}
            className="flex-1 h-11 rounded-xl bg-primary text-primary-foreground font-medium text-sm flex items-center justify-center gap-2 disabled:opacity-50">
            <Save className="h-4 w-4" />
            {saving ? "Saving…" : "Save changes"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main Screen ───────────────────────────────────────────────────────────────
function OrdersScreen() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [items, setItems] = useState<Record<string, OrderItem[]>>({});
  const [range, setRange] = useState<"day" | "week" | "month">("day");
  const [search, setSearch] = useState("");
  const [expanded, setExpanded] = useState<string | null>(null);
  const [editing, setEditing] = useState<Order | null>(null);
  const [currency, setCurrency] = useState("₹");
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    supabase.from("settings").select("value").eq("key", "restaurant").maybeSingle().then(({ data }) => {
      setCurrency(((data?.value ?? {}) as { currency?: string }).currency ?? "₹");
    });
  }, []);

  useEffect(() => {
    const now = new Date();
    let since: Date;
    if (range === "day") {
      since = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
    } else if (range === "week") {
      since = new Date(now); since.setUTCDate(since.getUTCDate() - 7);
    } else {
      since = new Date(now); since.setUTCMonth(since.getUTCMonth() - 1);
    }
    supabase.from("orders").select("*").eq("status", "billed")
      .gte("billed_at", since.toISOString()).order("billed_at", { ascending: false })
      .then(({ data }) => { setOrders((data ?? []) as Order[]); setExpanded(null); });
  }, [range]);

  const loadItems = async (orderId: string) => {
    if (items[orderId]) { setExpanded(expanded === orderId ? null : orderId); return; }
    const { data } = await supabase.from("order_items").select("*").eq("order_id", orderId);
    setItems((prev) => ({ ...prev, [orderId]: (data ?? []) as OrderItem[] }));
    setExpanded(orderId);
  };

  const handleExport = async () => {
    if (!filtered.length) return toast.info("No orders to export");
    setExporting(true);
    try { await exportToExcel(filtered, items, currency); toast.success(`Exported ${filtered.length} orders`); }
    finally { setExporting(false); }
  };

  const handleSaved = (updated: Order) => {
    setOrders((prev) => prev.map((o) => (o.id === updated.id ? updated : o)));
    setEditing(null);
  };

  const filtered = orders.filter((o) => {
    if (!search.trim()) return true;
    const s = search.toLowerCase();
    return String(o.bill_number).includes(s) || (o.table_name ?? "").toLowerCase().includes(s) || (o.payment_method ?? "").toLowerCase().includes(s);
  });

  const totalRev = filtered.reduce((s, o) => s + Number(o.total), 0);
  const methodBadge: Record<string, string> = {
    cash: "bg-success/15 text-success", upi: "bg-primary/10 text-primary", card: "bg-secondary text-secondary-foreground",
  };

  return (
    <div className="p-4 max-w-4xl mx-auto">
      <div className="flex items-center gap-2 mb-1">
        <ClipboardList className="h-5 w-5" />
        <h1 className="text-2xl font-semibold tracking-tight">Past Orders</h1>
      </div>
      <p className="text-sm text-muted-foreground mb-4">All settled bills.</p>

      <div className="flex flex-wrap gap-2 mb-4">
        {(["day", "week", "month"] as const).map((r) => (
          <button key={r} onClick={() => setRange(r)}
            className={`h-9 px-4 rounded-lg text-sm font-medium ${range === r ? "bg-foreground text-background" : "bg-secondary"}`}>
            {r === "day" ? "Today" : r === "week" ? "Last 7 days" : "Last 30 days"}
          </button>
        ))}
        <div className="flex items-center gap-2 bg-secondary rounded-lg px-3 h-9">
          <Search className="h-4 w-4 text-muted-foreground" />
          <input value={search} onChange={(e) => setSearch(e.target.value)}
            placeholder="Bill #, table, payment…" className="bg-transparent text-sm outline-none w-36" />
        </div>
        <button onClick={handleExport} disabled={exporting || !filtered.length}
          className="ml-auto h-9 px-4 rounded-lg bg-primary text-primary-foreground text-sm font-medium flex items-center gap-2 disabled:opacity-40 transition">
          <Download className="h-4 w-4" />
          {exporting ? "Exporting…" : "Export Excel"}
        </button>
      </div>

      <div className="surface rounded-2xl border p-4 mb-4 flex flex-wrap gap-6">
        <div><div className="text-xs text-muted-foreground">Orders</div><div className="text-2xl font-semibold">{filtered.length}</div></div>
        <div><div className="text-xs text-muted-foreground">Total revenue</div><div className="text-2xl font-semibold">{fmt(totalRev, currency)}</div></div>
        <div><div className="text-xs text-muted-foreground">Avg bill</div><div className="text-2xl font-semibold">{fmt(filtered.length ? totalRev / filtered.length : 0, currency)}</div></div>
      </div>

      <div className="surface rounded-2xl border divide-y overflow-hidden">
        {!filtered.length && <div className="p-8 text-center text-sm text-muted-foreground">No orders found.</div>}

        {filtered.map((o) => (
          <div key={o.id}>
            <div className="flex items-center gap-2 px-4 py-3 hover:bg-secondary/30 transition">
              <button onClick={() => loadItems(o.id)}
                className="flex-1 grid grid-cols-2 sm:grid-cols-4 gap-2 items-center text-left">
                <div><div className="font-mono text-xs text-muted-foreground">Bill</div><div className="font-semibold">#{o.bill_number}</div></div>
                <div><div className="text-xs text-muted-foreground">Table</div><div className="font-medium truncate">{o.table_name ?? "—"}</div></div>
                <div><div className="text-xs text-muted-foreground">Time</div><div className="text-sm">{dt(o.billed_at)}</div></div>
                <div className="flex items-center gap-2">
                  <div><div className="text-xs text-muted-foreground">Total</div><div className="font-semibold">{fmt(o.total, currency)}</div></div>
                  <span className={`text-xs font-medium px-2 py-1 rounded-lg capitalize ${methodBadge[o.payment_method ?? ""] ?? "bg-secondary"}`}>
                    {o.payment_method ?? "—"}
                  </span>
                </div>
              </button>
              <button onClick={() => setEditing(o)} title="Edit"
                className="shrink-0 h-8 w-8 grid place-items-center rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition">
                <Pencil className="h-4 w-4" />
              </button>
              <button onClick={() => loadItems(o.id)}
                className="shrink-0 h-8 w-8 grid place-items-center rounded-lg hover:bg-secondary text-muted-foreground transition">
                {expanded === o.id ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
              </button>
            </div>

            {o.notes && expanded !== o.id && (
              <div className="px-4 pb-2 -mt-1"><span className="text-xs text-muted-foreground italic">{o.notes}</span></div>
            )}

            {expanded === o.id && (
              <div className="px-4 pb-4 bg-secondary/20">
                {o.notes && <div className="text-xs text-muted-foreground italic mb-2 pt-1">{o.notes}</div>}
                <div className="rounded-xl border overflow-hidden">
                  <div className="grid grid-cols-12 text-xs font-semibold text-muted-foreground px-3 py-2 border-b bg-secondary/50">
                    <div className="col-span-6">Item</div><div className="col-span-2 text-center">Qty</div>
                    <div className="col-span-2 text-right">Rate</div><div className="col-span-2 text-right">Amount</div>
                  </div>
                  {(items[o.id] ?? []).filter((i) => i.status !== "rejected").map((i) => (
                    <div key={i.id} className="grid grid-cols-12 text-sm px-3 py-2 border-b last:border-0">
                      <div className="col-span-6 truncate">{i.name}</div>
                      <div className="col-span-2 text-center">{i.qty}</div>
                      <div className="col-span-2 text-right">{fmt(i.price, currency)}</div>
                      <div className="col-span-2 text-right">{fmt(Number(i.price) * i.qty, currency)}</div>
                    </div>
                  ))}
                  <div className="px-3 py-2 bg-secondary/30 text-sm flex justify-between"><span>Subtotal</span><span>{fmt(o.subtotal, currency)}</span></div>
                  <div className="px-3 py-2 bg-secondary/30 text-sm flex justify-between text-muted-foreground border-t"><span>Tax</span><span>{fmt(o.tax, currency)}</span></div>
                  <div className="px-3 py-2 bg-secondary/30 text-sm flex justify-between font-semibold border-t"><span>Total</span><span>{fmt(o.total, currency)}</span></div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {editing && (
        <EditOrderModal order={editing} currency={currency} onClose={() => setEditing(null)} onSaved={handleSaved} />
      )}
    </div>
  );
}
