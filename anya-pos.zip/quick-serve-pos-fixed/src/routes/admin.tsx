import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PinGate } from "@/components/PinGate";
import { AppShell } from "@/components/AppShell";
import { Plus, Trash2, BookOpen, FolderOpen, Pencil, Check, Loader2 } from "lucide-react";
import { toast } from "sonner";

/** Debounce: delays fn until ms have passed since last call */
function useDebounce<T extends (...args: Parameters<T>) => void>(fn: T, ms = 400): T {
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  return ((...args: Parameters<T>) => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => fn(...args), ms);
  }) as T;
}

export const Route = createFileRoute("/admin")({
  component: () => (
    <PinGate require="cashier">
      <AppShell><AdminScreen /></AppShell>
    </PinGate>
  ),
});

type Category = { id: string; name: string; color: string | null; sort_order: number };
type Item = { id: string; category_id: string | null; name: string; price: number; sale_price: number | null; description: string | null; available: boolean };
type Tbl = { id: string; name: string; sort_order: number; is_takeaway: boolean };

function AdminScreen() {
  const [tab, setTab] = useState<"menu" | "tables">("menu");
  return (
    <div className="p-4 max-w-5xl mx-auto">
      <h1 className="text-2xl font-semibold tracking-tight mb-1">Menu & Tables</h1>
      <p className="text-sm text-muted-foreground mb-4">Manage what staff can sell and where guests sit.</p>
      <div className="flex gap-2 mb-4">
        <button onClick={() => setTab("menu")} className={`px-4 h-10 rounded-lg text-sm font-medium flex items-center gap-2 ${tab === "menu" ? "bg-foreground text-background" : "bg-secondary"}`}>
          <BookOpen className="h-4 w-4" /> Menu
        </button>
        <button onClick={() => setTab("tables")} className={`px-4 h-10 rounded-lg text-sm font-medium flex items-center gap-2 ${tab === "tables" ? "bg-foreground text-background" : "bg-secondary"}`}>
          <FolderOpen className="h-4 w-4" /> Tables
        </button>
      </div>
      {tab === "menu" ? <MenuAdmin /> : <TableAdmin />}
    </div>
  );
}

function MenuAdmin() {
  const [cats, setCats] = useState<Category[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [active, setActive] = useState<string | null>(null);
  const [loadingCats, setLoadingCats] = useState(true);
  const [loadingItems, setLoadingItems] = useState(false);
  const [newCat, setNewCat] = useState("");
  // Category inline-edit state
  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [editingCatName, setEditingCatName] = useState("");

  // Load only categories on mount (fast)
  useEffect(() => {
    setLoadingCats(true);
    supabase.from("categories").select("*").order("sort_order").then(({ data }) => {
      const list = (data ?? []) as Category[];
      setCats(list);
      if (list.length) setActive(list[0].id);
      setLoadingCats(false);
    });
  }, []);

  // Load items only for the active category (lazy, fast)
  useEffect(() => {
    if (!active) return;
    setLoadingItems(true);
    supabase.from("items").select("*").eq("category_id", active).order("sort_order").then(({ data }) => {
      setItems((prev) => {
        // Merge: keep other categories' items, replace active category items
        const others = prev.filter((i) => i.category_id !== active);
        return [...others, ...((data ?? []) as Item[])];
      });
      setLoadingItems(false);
    });
  }, [active]);

  const reloadCats = async () => {
    const { data } = await supabase.from("categories").select("*").order("sort_order");
    setCats((data ?? []) as Category[]);
  };

  const reloadItems = async (catId = active) => {
    if (!catId) return;
    const { data } = await supabase.from("items").select("*").eq("category_id", catId).order("sort_order");
    setItems((prev) => {
      const others = prev.filter((i) => i.category_id !== catId);
      return [...others, ...((data ?? []) as Item[])];
    });
  };

  // ── Category actions ──
  const addCat = async () => {
    if (!newCat.trim()) return;
    const { data, error } = await supabase
      .from("categories").insert({ name: newCat.trim(), sort_order: cats.length + 1 }).select().single();
    if (error) return toast.error(error.message);
    setNewCat("");
    await reloadCats();
    setActive(data.id);
  };

  const deleteCat = async (id: string) => {
    if (!confirm("Delete category and all its items?")) return;
    await supabase.from("categories").delete().eq("id", id);
    if (active === id) setActive(null);
    await reloadCats();
  };

  const startEditCat = (c: Category) => {
    setEditingCatId(c.id);
    setEditingCatName(c.name);
  };

  const saveCatName = async (id: string) => {
    const name = editingCatName.trim();
    if (!name) { setEditingCatId(null); return; }
    const { error } = await supabase.from("categories").update({ name }).eq("id", id);
    if (error) return toast.error(error.message);
    setCats((prev) => prev.map((c) => (c.id === id ? { ...c, name } : c)));
    setEditingCatId(null);
    toast.success("Category renamed");
  };

  // ── Item actions ──
  const addItem = async () => {
    if (!active) return toast.info("Pick a category first");
    const { error } = await supabase
      .from("items").insert({ category_id: active, name: "New item", price: 0, sort_order: visible.length });
    if (error) return toast.error(error.message);
    await reloadItems();
  };

  const updateItem = (id: string, patch: Partial<Item>) => {
    setItems((xs) => xs.map((x) => (x.id === id ? { ...x, ...patch } : x)));
    debouncedSave(id, patch);
  };

  const debouncedSave = useDebounce(async (id: string, patch: Partial<Item>) => {
    await supabase.from("items").update(patch).eq("id", id);
  }, 400);

  const deleteItem = async (id: string) => {
    await supabase.from("items").delete().eq("id", id);
    await reloadItems();
  };

  const visible = items.filter((i) => i.category_id === active);

  return (
    <div className="grid md:grid-cols-[260px_1fr] gap-4">
      {/* Category sidebar */}
      <aside className="surface rounded-2xl border p-3 h-fit">
        <div className="text-xs font-semibold uppercase text-muted-foreground mb-2">Categories</div>

        {loadingCats ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground py-4 px-2">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading…
          </div>
        ) : (
          <div className="space-y-1">
            {cats.map((c) => (
              <div key={c.id} className={`group flex items-center gap-1 rounded-lg ${active === c.id ? "bg-secondary" : ""}`}>
                {editingCatId === c.id ? (
                  // ── Inline edit mode ──
                  <div className="flex flex-1 items-center gap-1 px-1">
                    <input
                      autoFocus
                      value={editingCatName}
                      onChange={(e) => setEditingCatName(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") saveCatName(c.id);
                        if (e.key === "Escape") setEditingCatId(null);
                      }}
                      className="flex-1 h-9 px-2 rounded-lg bg-background border text-sm"
                    />
                    <button onClick={() => saveCatName(c.id)} className="h-9 w-9 grid place-items-center rounded-lg bg-primary text-primary-foreground shrink-0">
                      <Check className="h-4 w-4" />
                    </button>
                  </div>
                ) : (
                  // ── Normal mode ──
                  <>
                    <button onClick={() => setActive(c.id)} className="flex-1 text-left px-3 h-10 text-sm font-medium truncate">
                      {c.name}
                    </button>
                    <button onClick={() => startEditCat(c)} className="opacity-0 group-hover:opacity-100 p-2 text-muted-foreground hover:text-foreground transition-opacity" title="Rename">
                      <Pencil className="h-3.5 w-3.5" />
                    </button>
                    <button onClick={() => deleteCat(c.id)} className="opacity-0 group-hover:opacity-100 p-2 text-destructive transition-opacity" title="Delete">
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </>
                )}
              </div>
            ))}
          </div>
        )}

        <div className="flex gap-1 mt-3">
          <input
            value={newCat}
            onChange={(e) => setNewCat(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addCat()}
            placeholder="New category"
            className="flex-1 h-10 px-3 rounded-lg bg-background border text-sm"
          />
          <button onClick={addCat} className="h-10 w-10 grid place-items-center rounded-lg bg-primary text-primary-foreground">
            <Plus className="h-4 w-4" />
          </button>
        </div>
      </aside>

      {/* Items panel */}
      <div className="surface rounded-2xl border p-3">
        <div className="flex items-center justify-between mb-3">
          <div className="text-xs font-semibold uppercase text-muted-foreground">
            Items {active && cats.find((c) => c.id === active) ? `— ${cats.find((c) => c.id === active)!.name}` : ""}
          </div>
          <button onClick={addItem} className="h-9 px-3 rounded-lg bg-primary text-primary-foreground text-sm font-medium flex items-center gap-1">
            <Plus className="h-4 w-4" /> Add item
          </button>
        </div>

        {loadingItems ? (
          <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground py-12">
            <Loader2 className="h-5 w-5 animate-spin" /> Loading items…
          </div>
        ) : (
          <div className="space-y-2">
            {visible.map((it) => (
              <div key={it.id} className="rounded-xl border p-3 bg-card grid grid-cols-1 md:grid-cols-12 gap-2 items-center">
                <input
                  value={it.name}
                  onChange={(e) => updateItem(it.id, { name: e.target.value })}
                  className="md:col-span-4 h-10 px-3 rounded-lg bg-background border text-sm"
                  placeholder="Name"
                />
                <input
                  value={it.description ?? ""}
                  onChange={(e) => updateItem(it.id, { description: e.target.value })}
                  className="md:col-span-3 h-10 px-3 rounded-lg bg-background border text-sm"
                  placeholder="Description"
                />
                <input
                  type="number" inputMode="decimal"
                  value={it.price}
                  onChange={(e) => updateItem(it.id, { price: Number(e.target.value) })}
                  className="md:col-span-1 h-10 px-3 rounded-lg bg-background border text-sm"
                  placeholder="Price"
                />
                <input
                  type="number" inputMode="decimal"
                  value={it.sale_price ?? ""}
                  onChange={(e) => updateItem(it.id, { sale_price: e.target.value === "" ? null : Number(e.target.value) })}
                  className="md:col-span-2 h-10 px-3 rounded-lg bg-background border text-sm"
                  placeholder="Sale price"
                />
                <label className="md:col-span-1 flex items-center gap-2 text-xs cursor-pointer">
                  <input type="checkbox" checked={it.available} onChange={(e) => updateItem(it.id, { available: e.target.checked })} />
                  Avail
                </label>
                <button onClick={() => deleteItem(it.id)} className="md:col-span-1 h-10 grid place-items-center rounded-lg text-destructive hover:bg-destructive/10">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
            {!visible.length && !loadingItems && (
              <div className="text-sm text-muted-foreground text-center py-8">No items yet. Click "Add item" above.</div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function TableAdmin() {
  const [tables, setTables] = useState<Tbl[]>([]);
  const [name, setName] = useState("");
  const [takeaway, setTakeaway] = useState(false);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("restaurant_tables").select("*").order("sort_order");
    setTables((data ?? []) as Tbl[]);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const add = async () => {
    if (!name.trim()) return;
    await supabase.from("restaurant_tables").insert({ name: name.trim(), is_takeaway: takeaway, sort_order: tables.length + 1 });
    setName(""); setTakeaway(false);
    load();
  };

  const del = async (id: string) => {
    if (!confirm("Delete table?")) return;
    await supabase.from("restaurant_tables").delete().eq("id", id);
    load();
  };

  return (
    <div className="surface rounded-2xl border p-4">
      <div className="flex flex-wrap gap-2 items-end mb-4">
        <div>
          <label className="text-xs text-muted-foreground">Name</label>
          <input value={name} onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.key === "Enter" && add()}
            className="h-10 px-3 rounded-lg bg-background border text-sm block" placeholder="Table 7" />
        </div>
        <label className="flex items-center gap-2 text-sm h-10">
          <input type="checkbox" checked={takeaway} onChange={(e) => setTakeaway(e.target.checked)} /> Takeaway
        </label>
        <button onClick={add} className="h-10 px-4 rounded-lg bg-primary text-primary-foreground font-medium flex items-center gap-1">
          <Plus className="h-4 w-4" /> Add
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground py-8">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading…
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
          {tables.map((t) => (
            <div key={t.id} className="rounded-xl border p-3 bg-card flex items-center justify-between">
              <div>
                <div className="font-medium text-sm">{t.name}</div>
                {t.is_takeaway && <div className="text-[10px] uppercase text-muted-foreground">Takeaway</div>}
              </div>
              <button onClick={() => del(t.id)} className="text-destructive p-1.5 rounded hover:bg-destructive/10">
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
