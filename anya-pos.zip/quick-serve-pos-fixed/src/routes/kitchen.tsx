import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PinGate } from "@/components/PinGate";
import { AppShell } from "@/components/AppShell";
import { timeAgo } from "@/lib/format";
import { sendNotification } from "@/lib/notifications";
import { Check, X, ChefHat, CheckCheck, Clock, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/kitchen")({
  component: () => (
    <PinGate require="kitchen">
      <AppShell><KitchenScreen /></AppShell>
    </PinGate>
  ),
});

type Order = { id: string; bill_number: number; table_name: string | null; created_at: string; status: string };
type Item = { id: string; order_id: string; name: string; qty: number; status: string; notes: string | null; created_at: string };

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-warning/15 border-warning/40",
  preparing: "bg-primary/10 border-primary/40",
  ready: "bg-success/15 border-success/50",
  rejected: "bg-destructive/10 border-destructive/40",
  served: "bg-muted border-muted-foreground/20",
};

function KitchenScreen() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [showServed, setShowServed] = useState(false);
  const knownItemIds = useRef<Set<string>>(new Set());

  const load = async () => {
    const { data: o } = await supabase.from("orders").select("*").eq("status", "open").order("created_at", { ascending: true });
    setOrders((o ?? []) as Order[]);
    if (o?.length) {
      const { data: oi } = await supabase.from("order_items").select("*").in("order_id", o.map((x) => x.id)).order("created_at");
      const incoming = (oi ?? []) as Item[];

      // Fire notifications for new pending items
      incoming.filter((i) => i.status === "pending" && !knownItemIds.current.has(i.id)).forEach((i) => {
        sendNotification("🍽️ New order item", `${i.name} ×${i.qty}`);
        toast.info(`New: ${i.name} ×${i.qty}`, { duration: 4000 });
      });
      incoming.forEach((i) => knownItemIds.current.add(i.id));

      setItems(incoming);
    } else {
      setItems([]);
    }
  };

  useEffect(() => {
    load();
    const ch = supabase.channel("kds")
      .on("postgres_changes", { event: "*", schema: "public", table: "orders" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "order_items" }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  const itemsFor = (oid: string) => {
    const all = items.filter((i) => i.order_id === oid);
    if (showServed) return all;
    return all.filter((i) => i.status !== "served" && i.status !== "rejected");
  };

  const setItemStatus = async (id: string, status: string) => {
    await supabase.from("order_items").update({ status }).eq("id", id);
  };

  const completeAll = async (oid: string) => {
    await supabase.from("order_items").update({ status: "ready" }).eq("order_id", oid).in("status", ["pending", "preparing"]);
    toast.success("All items marked ready");
  };

  const acceptAll = async (oid: string) => {
    await supabase.from("order_items").update({ status: "preparing" }).eq("order_id", oid).eq("status", "pending");
  };

  const visibleOrders = orders.filter((o) => itemsFor(o.id).length > 0);
  const activeCount = orders.filter((o) => items.filter((i) => i.order_id === o.id && i.status !== "served" && i.status !== "rejected").length > 0).length;

  return (
    <div className="p-4 h-[calc(100vh-3.5rem)] overflow-auto">
      <div className="flex items-center gap-2 mb-4">
        <ChefHat className="h-5 w-5" />
        <h1 className="text-xl font-semibold">Kitchen Display</h1>
        <span className="ml-2 text-xs text-muted-foreground">{activeCount} active</span>
        <button
          onClick={() => setShowServed((v) => !v)}
          className={`ml-auto flex items-center gap-1.5 h-9 px-3 rounded-lg text-xs font-medium border transition ${showServed ? "bg-foreground text-background border-foreground" : "bg-secondary border-border"}`}
        >
          {showServed ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
          {showServed ? "All statuses" : "Active only"}
        </button>
      </div>

      {!visibleOrders.length && (
        <div className="text-center text-muted-foreground py-24">
          <CheckCheck className="h-10 w-10 mx-auto opacity-30 mb-3" />
          <p>All caught up. New orders appear instantly.</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {visibleOrders.map((o) => {
          const its = itemsFor(o.id);
          const ageMin = (Date.now() - new Date(o.created_at).getTime()) / 60000;
          const delayed = ageMin > 15;
          return (
            <div key={o.id} className={`rounded-2xl border-2 surface shadow-soft flex flex-col ${delayed ? "border-destructive" : "border-border"}`}>
              <div className="p-3 border-b flex items-center justify-between">
                <div>
                  <div className="text-xs text-muted-foreground">#{o.bill_number}</div>
                  <div className="font-semibold">{o.table_name ?? "—"}</div>
                </div>
                <div className={`text-xs flex items-center gap-1 ${delayed ? "text-destructive font-semibold" : "text-muted-foreground"}`}>
                  <Clock className="h-3 w-3" /> {timeAgo(o.created_at)}
                </div>
              </div>
              <div className="p-3 space-y-2 flex-1">
                {its.map((i) => (
                  <KitchenItem key={i.id} item={i} onUpdate={setItemStatus} />
                ))}
              </div>
              <div className="p-3 border-t grid grid-cols-2 gap-2">
                <button onClick={() => acceptAll(o.id)} className="h-10 rounded-lg bg-secondary font-medium text-sm">Accept all</button>
                <button onClick={() => completeAll(o.id)} className="h-10 rounded-lg bg-success text-success-foreground font-medium text-sm">Ready all</button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function KitchenItem({ item, onUpdate }: { item: Item; onUpdate: (id: string, status: string) => void }) {
  const transitions: Record<string, { label: string; status: string; style: string }[]> = {
    pending: [
      { label: "Prep", status: "preparing", style: "bg-primary text-primary-foreground" },
      { label: "Reject", status: "rejected", style: "bg-destructive/10 text-destructive" },
    ],
    preparing: [
      { label: "Ready", status: "ready", style: "bg-success text-success-foreground" },
      { label: "Pending", status: "pending", style: "bg-warning/20 text-warning-foreground" },
    ],
    ready: [
      { label: "Served", status: "served", style: "bg-muted text-muted-foreground" },
      { label: "Prep", status: "preparing", style: "bg-primary/10 text-primary" },
    ],
    served: [
      { label: "Undo", status: "ready", style: "bg-muted text-muted-foreground" },
    ],
    rejected: [
      { label: "Restore", status: "pending", style: "bg-secondary text-secondary-foreground" },
    ],
  };

  const btns = transitions[item.status] ?? [];

  return (
    <div className={`rounded-xl border-2 p-2 ${STATUS_COLORS[item.status] ?? "bg-card"}`}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className={`font-medium text-sm leading-tight ${item.status === "served" || item.status === "rejected" ? "opacity-50" : ""}`}>
            <span className="font-bold mr-1">×{item.qty}</span>{item.name}
          </div>
          {item.notes && <div className="text-xs text-muted-foreground mt-0.5 italic truncate">{item.notes}</div>}
          <div className="text-[10px] uppercase font-bold mt-1 text-muted-foreground">{item.status}</div>
        </div>
        <div className="flex flex-col gap-1 shrink-0">
          {btns.map((b) => (
            <button key={b.status} onClick={() => onUpdate(item.id, b.status)}
              className={`h-7 px-2 rounded-md text-xs font-medium flex items-center gap-1 ${b.style}`}>
              {b.status === "ready" && <Check className="h-3 w-3" />}
              {b.status === "rejected" && <X className="h-3 w-3" />}
              {b.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
