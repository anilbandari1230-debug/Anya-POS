import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PinGate } from "@/components/PinGate";
import { AppShell } from "@/components/AppShell";
import { Save, Settings as SettingsIcon, UserPlus, Trash2, ChefHat, Utensils } from "lucide-react";
import { toast } from "sonner";
import { hashPin, type StaffUser } from "@/lib/auth";

export const Route = createFileRoute("/settings")({
  component: () => (
    <PinGate require="cashier">
      <AppShell><SettingsScreen /></AppShell>
    </PinGate>
  ),
});

function SettingsScreen() {
  const [restaurant, setRestaurant] = useState({ name: "", address: "", phone: "", currency: "₹", tax_percent: 5 });
  const [upi, setUpi] = useState({ upi_id: "", payee_name: "" });
  const [printer, setPrinter] = useState({ paper_size: "80mm", type: "bluetooth" });
  const [staff, setStaff] = useState<StaffUser[]>([]);
  const [newStaff, setNewStaff] = useState({ name: "", pin: "", role: "cashier" as "cashier" | "kitchen" });
  const [addingStaff, setAddingStaff] = useState(false);

  useEffect(() => {
    supabase.from("settings").select("*").then(({ data }) => {
      (data ?? []).forEach((row) => {
        if (row.key === "restaurant") setRestaurant((prev) => ({ ...prev, ...(row.value as any) }));
        if (row.key === "upi") setUpi((prev) => ({ ...prev, ...(row.value as any) }));
        if (row.key === "printer") setPrinter((prev) => ({ ...prev, ...(row.value as any) }));
        if (row.key === "staff") setStaff((row.value as StaffUser[]) ?? []);
      });
    });
  }, []);

  const saveGeneral = async () => {
    await Promise.all([
      supabase.from("settings").upsert({ key: "restaurant", value: restaurant as any, updated_at: new Date().toISOString() }),
      supabase.from("settings").upsert({ key: "upi", value: upi as any, updated_at: new Date().toISOString() }),
      supabase.from("settings").upsert({ key: "printer", value: printer as any, updated_at: new Date().toISOString() }),
    ]);
    toast.success("Settings saved");
  };

  const addStaffMember = async () => {
    if (!newStaff.name.trim()) return toast.error("Enter a name");
    if (newStaff.pin.length < 4) return toast.error("PIN must be at least 4 digits");
    if (!/^\d+$/.test(newStaff.pin)) return toast.error("PIN must be numbers only");

    setAddingStaff(true);
    const pinHash = await hashPin(newStaff.pin.trim());
    const member: StaffUser = {
      id: crypto.randomUUID(),
      name: newStaff.name.trim(),
      pinHash,
      role: newStaff.role,
    };
    const updated = [...staff, member];
    const { error } = await supabase.from("settings").upsert({
      key: "staff", value: updated as any, updated_at: new Date().toISOString(),
    });
    setAddingStaff(false);
    if (error) return toast.error(error.message);
    setStaff(updated);
    setNewStaff({ name: "", pin: "", role: "cashier" });
    toast.success(`${member.name} added`);
  };

  const removeStaff = async (id: string) => {
    const updated = staff.filter((s) => s.id !== id);
    await supabase.from("settings").upsert({ key: "staff", value: updated as any, updated_at: new Date().toISOString() });
    setStaff(updated);
    toast.success("Staff member removed");
  };

  const roleIcon = (role: string) =>
    role === "kitchen" ? <ChefHat className="h-3.5 w-3.5" /> : <Utensils className="h-3.5 w-3.5" />;

  const roleBadge = (role: string) =>
    role === "kitchen"
      ? "bg-primary/10 text-primary"
      : "bg-success/15 text-success";

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <div className="flex items-center gap-2 mb-1"><SettingsIcon className="h-5 w-5" /><h1 className="text-2xl font-semibold tracking-tight">Settings</h1></div>
      <p className="text-sm text-muted-foreground mb-4">Restaurant info, payment, and staff.</p>

      {/* Restaurant */}
      <Section title="Restaurant">
        <Field label="Name" value={restaurant.name} onChange={(v) => setRestaurant((p) => ({ ...p, name: v }))} />
        <Field label="Address" value={restaurant.address} onChange={(v) => setRestaurant((p) => ({ ...p, address: v }))} />
        <Field label="Phone" value={restaurant.phone} onChange={(v) => setRestaurant((p) => ({ ...p, phone: v }))} />
        <div className="grid grid-cols-2 gap-3">
          <Field label="Currency" value={restaurant.currency} onChange={(v) => setRestaurant((p) => ({ ...p, currency: v }))} />
          <Field label="Tax %" type="number" value={String(restaurant.tax_percent)} onChange={(v) => setRestaurant((p) => ({ ...p, tax_percent: Number(v) }))} />
        </div>
      </Section>

      {/* UPI */}
      <Section title="UPI Payment">
        <Field label="UPI ID" value={upi.upi_id} onChange={(v) => setUpi((p) => ({ ...p, upi_id: v }))} placeholder="merchant@upi" />
        <Field label="Payee name" value={upi.payee_name} onChange={(v) => setUpi((p) => ({ ...p, payee_name: v }))} />
      </Section>

      <Section title="Printer">
        <p className="text-xs text-muted-foreground -mt-2 mb-3">
          Android uses Bluetooth. iPhone uses WiFi print. Buy a printer with both (e.g. Rongta RPP300).
        </p>
        <div>
          <div className="text-xs text-muted-foreground mb-2">Paper size</div>
          <div className="grid grid-cols-2 gap-2">
            {(["58mm", "80mm"] as const).map((s) => (
              <button key={s} onClick={() => setPrinter((p) => ({ ...p, paper_size: s }))}
                className={`h-11 rounded-xl border-2 text-sm font-medium transition ${printer.paper_size === s ? "border-primary bg-primary/5 text-primary" : "border-border bg-card"}`}>
                {s} {s === "80mm" ? "(recommended)" : ""}
              </button>
            ))}
          </div>
        </div>
      </Section>

      <button onClick={saveGeneral}
        className="h-12 w-full rounded-xl bg-primary text-primary-foreground font-semibold flex items-center justify-center gap-2 mb-6">
        <Save className="h-4 w-4" /> Save settings
      </button>

      {/* Staff Management */}
      <Section title="Staff Users">
        <p className="text-xs text-muted-foreground -mt-2 mb-3">
          Each staff member has their own name and PIN. PINs are hashed — you cannot read them back.
        </p>

        {/* Existing staff */}
        {staff.length === 0 ? (
          <div className="text-sm text-muted-foreground text-center py-4 border rounded-xl">
            No staff added yet. Add your first staff member below.
          </div>
        ) : (
          <div className="space-y-2 mb-4">
            {staff.map((s) => (
              <div key={s.id} className="flex items-center gap-3 rounded-xl border p-3 bg-card">
                <div className="h-9 w-9 rounded-lg bg-secondary grid place-items-center text-sm font-bold shrink-0">
                  {s.name[0].toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm truncate">{s.name}</div>
                </div>
                <span className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-lg capitalize ${roleBadge(s.role)}`}>
                  {roleIcon(s.role)} {s.role}
                </span>
                <button onClick={() => removeStaff(s.id)} className="text-destructive p-1.5 rounded-lg hover:bg-destructive/10 shrink-0">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Add staff form */}
        <div className="rounded-xl border p-4 bg-secondary/30 space-y-3">
          <div className="text-xs font-semibold uppercase text-muted-foreground">Add new staff member</div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Name" value={newStaff.name} onChange={(v) => setNewStaff((p) => ({ ...p, name: v }))} placeholder="e.g. Ravi" />
            <Field label="PIN (4+ digits)" value={newStaff.pin} onChange={(v) => setNewStaff((p) => ({ ...p, pin: v.replace(/\D/g, "") }))} placeholder="e.g. 7291" />
          </div>
          <div>
            <div className="text-xs text-muted-foreground mb-2">Role</div>
            <div className="grid grid-cols-2 gap-2">
              {(["cashier", "kitchen"] as const).map((r) => (
                <button key={r} onClick={() => setNewStaff((p) => ({ ...p, role: r }))}
                  className={`h-11 rounded-xl border-2 text-sm font-medium capitalize flex items-center justify-center gap-2 transition ${newStaff.role === r ? "border-primary bg-primary/5 text-primary" : "border-border bg-card"}`}>
                  {r === "kitchen" ? <ChefHat className="h-4 w-4" /> : <Utensils className="h-4 w-4" />} {r}
                </button>
              ))}
            </div>
          </div>
          <button onClick={addStaffMember} disabled={addingStaff}
            className="w-full h-11 rounded-xl bg-primary text-primary-foreground font-medium flex items-center justify-center gap-2 disabled:opacity-50">
            <UserPlus className="h-4 w-4" />
            {addingStaff ? "Adding…" : "Add staff member"}
          </button>
        </div>
      </Section>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="surface rounded-2xl border p-4 mb-4">
      <h2 className="font-semibold mb-3">{title}</h2>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function Field({ label, value, onChange, type = "text", placeholder }: {
  label: string; value: string; onChange: (v: string) => void; type?: string; placeholder?: string;
}) {
  return (
    <label className="block">
      <div className="text-xs text-muted-foreground mb-1">{label}</div>
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder}
        className="h-11 w-full px-3 rounded-lg bg-background border text-sm" />
    </label>
  );
}
