import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PinGate } from "@/components/PinGate";
import { AppShell } from "@/components/AppShell";
import { fmt } from "@/lib/format";
import { toast } from "sonner";
import { sendNotification } from "@/lib/notifications";
import { Plus, Minus, Trash2, Send, Receipt, X, Users, ShoppingBag, ChevronLeft, Check } from "lucide-react";
import QRCode from "qrcode";

export const Route = createFileRoute("/")({
  component: () => (
    <PinGate require="cashier">
      <AppShell>
        <PosScreen />
      </AppShell>
    </PinGate>
  ),
});

type Table = { id: string; name: string; sort_order: number; is_takeaway: boolean };
type Category = { id: string; name: string; color: string | null; sort_order: number };
type Item = { id: string; category_id: string | null; name: string; price: number; sale_price: number | null; description: string | null; available: boolean; photo_url: string | null };
type OrderRow = { id: string; bill_number: number; table_id: string | null; table_name: string | null; status: string; subtotal: number; tax: number; total: number; created_at: string; payment_method: string | null; payment_status: string | null };
type OrderItem = { id: string; order_id: string; item_id: string | null; name: string; qty: number; price: number; notes: string | null; status: string; created_at: string };

function PosScreen() {
  const [tables, setTables] = useState<Table[]>([]);
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [orderItems, setOrderItems] = useState<Record<string, OrderItem[]>>({});
  const [selectedTable, setSelectedTable] = useState<Table | null>(null);
  const [view, setView] = useState<"tables" | "menu">("tables");
  const prevItemStatuses = useRef<Record<string, string>>({});

  // Load
  const loadAll = async () => {
    const [t, o] = await Promise.all([
      supabase.from("restaurant_tables").select("*").order("sort_order"),
      supabase.from("orders").select("*").eq("status", "open").order("created_at", { ascending: false }),
    ]);
    setTables(t.data ?? []);
    setOrders(o.data ?? []);
    if (o.data && o.data.length) {
      const ids = o.data.map((x) => x.id);
      const { data: oi } = await supabase.from("order_items").select("*").in("order_id", ids);
      const grouped: Record<string, OrderItem[]> = {};
      (oi ?? []).forEach((row) => {
        (grouped[row.order_id] ??= []).push(row as OrderItem);
        // Notify cashier when an item becomes "ready"
        if (row.status === "ready" && prevItemStatuses.current[row.id] && prevItemStatuses.current[row.id] !== "ready") {
          sendNotification("✅ Item ready", `${row.name} ×${row.qty} is ready to serve`);
          toast.success(`${row.name} is ready`, { duration: 4000 });
        }
        prevItemStatuses.current[row.id] = row.status;
      });
      setOrderItems(grouped);
    } else {
      setOrderItems({});
    }
  };

  useEffect(() => {
    loadAll();
    const ch = supabase
      .channel("pos-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "orders" }, () => loadAll())
      .on("postgres_changes", { event: "*", schema: "public", table: "order_items" }, () => loadAll())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  const orderForTable = (tid: string) => orders.find((o) => o.table_id === tid) ?? null;

  const openTable = (t: Table) => {
    setSelectedTable(t);
    setView("menu");
  };

  return (
    <div className="h-[calc(100vh-3.5rem)] flex">
      {/* Left: Tables grid (always visible on desktop, full screen on mobile when view=tables) */}
      <aside className={`${view === "tables" ? "flex" : "hidden"} md:flex flex-col w-full md:w-80 lg:w-96 border-r surface`}>
        <div className="p-4 border-b">
          <h2 className="text-lg font-semibold flex items-center gap-2"><Users className="h-5 w-5" /> Tables</h2>
          <p className="text-xs text-muted-foreground mt-1">Tap a table to start or continue an order</p>
        </div>
        <div className="flex-1 overflow-auto p-4 grid grid-cols-2 gap-3">
          {tables.map((t) => {
            const o = orderForTable(t.id);
            const items = o ? orderItems[o.id] ?? [] : [];
            const Icon = t.is_takeaway ? ShoppingBag : Users;
            return (
              <button
                key={t.id}
                onClick={() => openTable(t)}
                className={`tap aspect-square rounded-2xl border-2 p-3 text-left transition shadow-soft active:scale-[0.97] flex flex-col ${
                  selectedTable?.id === t.id
                    ? "border-primary bg-primary/5"
                    : o
                    ? "border-success/50 bg-success/5"
                    : "border-border bg-card hover:border-primary/40"
                }`}
              >
                <div className="flex items-start justify-between">
                  <Icon className={`h-5 w-5 ${o ? "text-success" : "text-muted-foreground"}`} />
                  {o && <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-success text-success-foreground">#{o.bill_number}</span>}
                </div>
                <div className="mt-auto">
                  <div className="font-semibold text-base leading-tight">{t.name}</div>
                  {o ? (
                    <div className="text-xs text-muted-foreground mt-1">
                      {items.length} item{items.length !== 1 ? "s" : ""} · {fmt(o.total)}
                    </div>
                  ) : (
                    <div className="text-xs text-muted-foreground mt-1">Free</div>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </aside>

      {/* Right: Menu / order */}
      <section className={`${view === "menu" ? "flex" : "hidden"} md:flex flex-1 min-w-0`}>
        {selectedTable ? (
          <TableOrderView
            table={selectedTable}
            existingOrder={orderForTable(selectedTable.id)}
            existingItems={orderForTable(selectedTable.id) ? orderItems[orderForTable(selectedTable.id)!.id] ?? [] : []}
            onBack={() => setView("tables")}
            onChange={loadAll}
          />
        ) : (
          <div className="flex-1 grid place-items-center text-muted-foreground">
            <div className="text-center">
              <Users className="h-10 w-10 mx-auto mb-2 opacity-40" />
              <p>Select a table to begin</p>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}

/* ---------------- Table Order View ---------------- */
type Draft = { item: Item; qty: number; notes?: string };

function TableOrderView({
  table, existingOrder, existingItems, onBack, onChange,
}: {
  table: Table;
  existingOrder: OrderRow | null;
  existingItems: OrderItem[];
  onBack: () => void;
  onChange: () => void;
}) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [activeCat, setActiveCat] = useState<string | null>(null);
  const [draft, setDraft] = useState<Draft[]>([]);
  const [billOpen, setBillOpen] = useState(false);
  const [tax, setTax] = useState(5);
  const [currency, setCurrency] = useState("₹");

  useEffect(() => {
    setDraft([]);
    Promise.all([
      supabase.from("categories").select("*").order("sort_order"),
      supabase.from("items").select("*").order("sort_order"),
      supabase.from("settings").select("value").eq("key", "restaurant").maybeSingle(),
    ]).then(([c, i, s]) => {
      const cats = c.data ?? [];
      setCategories(cats);
      setItems(i.data ?? []);
      if (cats.length) setActiveCat(cats[0].id);
      const v = (s.data?.value ?? {}) as { tax_percent?: number; currency?: string };
      setTax(v.tax_percent ?? 5);
      setCurrency(v.currency ?? "₹");
    });
  }, [table.id]);

  const filtered = useMemo(() => items.filter((x) => x.category_id === activeCat && x.available), [items, activeCat]);

  const addItem = (it: Item) => {
    setDraft((d) => {
      const idx = d.findIndex((x) => x.item.id === it.id);
      if (idx >= 0) {
        const copy = [...d];
        copy[idx] = { ...copy[idx], qty: copy[idx].qty + 1 };
        return copy;
      }
      return [...d, { item: it, qty: 1 }];
    });
  };

  const updateDraft = (id: string, qty: number) => {
    setDraft((d) => d.flatMap((x) => (x.item.id === id ? (qty <= 0 ? [] : [{ ...x, qty }]) : [x])));
  };

  // Combined display: existing items + new draft
  const draftSubtotal = draft.reduce((s, d) => s + Number(d.item.sale_price ?? d.item.price) * d.qty, 0);
  const existingSubtotal = existingItems
    .filter((i) => i.status !== "rejected")
    .reduce((s, i) => s + Number(i.price) * i.qty, 0);
  const subtotal = existingSubtotal + draftSubtotal;
  const taxAmt = (subtotal * tax) / 100;
  const total = subtotal + taxAmt;

  const sendToKitchen = async () => {
    if (!draft.length) return toast.info("Add items first");
    let orderId = existingOrder?.id;
    if (!orderId) {
      const { data, error } = await supabase
        .from("orders")
        .insert({ table_id: table.id, table_name: table.name, status: "open" })
        .select()
        .single();
      if (error || !data) return toast.error(error?.message ?? "Failed");
      orderId = data.id;
    }
    const rows = draft.map((d) => ({
      order_id: orderId!,
      item_id: d.item.id,
      name: d.item.name,
      qty: d.qty,
      price: Number(d.item.sale_price ?? d.item.price),
      notes: d.notes ?? null,
      status: "pending" as const,
    }));
    const { error } = await supabase.from("order_items").insert(rows);
    if (error) return toast.error(error.message);
    // Update totals
    await refreshOrderTotals(orderId!);
    toast.success("Sent to kitchen");
    setDraft([]);
    onChange();
  };

  const removeExisting = async (id: string) => {
    await supabase.from("order_items").delete().eq("id", id);
    if (existingOrder) await refreshOrderTotals(existingOrder.id);
    onChange();
  };

  const updateExistingQty = async (id: string, qty: number) => {
    if (qty <= 0) return removeExisting(id);
    await supabase.from("order_items").update({ qty }).eq("id", id);
    if (existingOrder) await refreshOrderTotals(existingOrder.id);
    onChange();
  };

  const updateItemStatus = async (id: string, status: string) => {
    await supabase.from("order_items").update({ status }).eq("id", id);
    onChange();
  };

  return (
    <div className="flex-1 flex min-w-0">
      {/* Categories + items */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="p-4 border-b surface flex items-center gap-3">
          <button onClick={onBack} className="md:hidden p-2 -ml-2 rounded-lg hover:bg-secondary">
            <ChevronLeft className="h-5 w-5" />
          </button>
          <div className="min-w-0">
            <div className="text-xs text-muted-foreground">Now serving</div>
            <h2 className="text-lg font-semibold truncate">{table.name}</h2>
          </div>
        </div>

        <div className="flex gap-2 p-3 border-b overflow-x-auto surface">
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setActiveCat(c.id)}
              className={`tap shrink-0 px-4 h-11 rounded-xl text-sm font-medium border-2 transition shadow-soft ${
                activeCat === c.id ? "bg-foreground text-background border-foreground" : "bg-card border-border hover:border-foreground/40"
              }`}
              style={activeCat === c.id ? undefined : { borderLeftColor: c.color ?? "#94a3b8", borderLeftWidth: 4 }}
            >
              {c.name}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-auto p-4 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 content-start">
          {filtered.map((it) => {
            const price = Number(it.sale_price ?? it.price);
            const onSale = it.sale_price != null && Number(it.sale_price) < Number(it.price);
            return (
              <button
                key={it.id}
                onClick={() => addItem(it)}
                className="tap text-left rounded-2xl bg-card border shadow-soft p-3 hover:border-primary hover:shadow-pop transition active:scale-[0.97] flex flex-col"
              >
                <div className="font-medium leading-tight">{it.name}</div>
                {it.description && <div className="text-xs text-muted-foreground mt-1 line-clamp-2">{it.description}</div>}
                <div className="mt-3 flex items-end gap-2">
                  <span className="text-lg font-semibold">{fmt(price, currency)}</span>
                  {onSale && <span className="text-xs text-muted-foreground line-through">{fmt(it.price, currency)}</span>}
                </div>
              </button>
            );
          })}
          {!filtered.length && <div className="col-span-full text-sm text-muted-foreground text-center py-12">No items in this category</div>}
        </div>
      </div>

      {/* Cart */}
      <aside className="w-full max-w-sm border-l surface flex flex-col hidden lg:flex">
        <CartView
          table={table}
          existing={existingItems}
          draft={draft}
          subtotal={subtotal}
          tax={tax}
          taxAmt={taxAmt}
          total={total}
          currency={currency}
          onUpdateDraft={updateDraft}
          onUpdateExisting={updateExistingQty}
          onUpdateItemStatus={updateItemStatus}
          onRemoveExisting={removeExisting}
          onSend={sendToKitchen}
          onBill={() => setBillOpen(true)}
          existingOrder={existingOrder}
        />
      </aside>

      {/* Mobile cart sheet */}
      <MobileCartBar
        count={draft.length + existingItems.length}
        total={total}
        currency={currency}
        onSend={sendToKitchen}
        onBill={() => setBillOpen(true)}
        canBill={!!existingOrder && !draft.length}
      >
        <CartView
          table={table}
          existing={existingItems}
          draft={draft}
          subtotal={subtotal}
          tax={tax}
          taxAmt={taxAmt}
          total={total}
          currency={currency}
          onUpdateDraft={updateDraft}
          onUpdateExisting={updateExistingQty}
          onUpdateItemStatus={updateItemStatus}
          onRemoveExisting={removeExisting}
          onSend={sendToKitchen}
          onBill={() => setBillOpen(true)}
          existingOrder={existingOrder}
        />
      </MobileCartBar>

      {billOpen && existingOrder && (
        <BillDialog
          orderId={existingOrder.id}
          tax={tax}
          currency={currency}
          onClose={() => { setBillOpen(false); onChange(); }}
        />
      )}
    </div>
  );
}

async function refreshOrderTotals(orderId: string) {
  // BUG-002 fix: always re-fetch tax rate from DB so stale local state can't cause wrong totals
  const { data: s } = await supabase.from("settings").select("value").eq("key", "restaurant").maybeSingle();
  const taxPercent = ((s?.value ?? {}) as { tax_percent?: number }).tax_percent ?? 5;

  const { data } = await supabase
    .from("order_items")
    .select("price, qty, status")
    .eq("order_id", orderId);
  const subtotal = (data ?? [])
    .filter((r) => r.status !== "rejected")
    .reduce((s, r) => s + Number(r.price) * r.qty, 0);
  const tax = (subtotal * taxPercent) / 100;
  await supabase.from("orders").update({ subtotal, tax, total: subtotal + tax }).eq("id", orderId);
}

/* ── Shared status button ── */
function StatusBtn({ label, onClick, color, icon }: { label: string; onClick: () => void; color: string; icon?: React.ReactNode }) {
  return (
    <button onClick={onClick} className={`h-7 px-2 rounded-md text-xs font-medium flex items-center gap-1 transition active:scale-95 ${color}`}>
      {icon}{label}
    </button>
  );
}

/* ---------------- Cart ---------------- */
function CartView(props: {
  table: Table;
  existing: OrderItem[];
  draft: Draft[];
  subtotal: number; tax: number; taxAmt: number; total: number; currency: string;
  onUpdateDraft: (id: string, qty: number) => void;
  onUpdateExisting: (id: string, qty: number) => void;
  onUpdateItemStatus: (id: string, status: string) => void;
  onRemoveExisting: (id: string) => void;
  onSend: () => void;
  onBill: () => void;
  existingOrder: OrderRow | null;
}) {
  const { existing, draft, subtotal, tax, taxAmt, total, currency, onUpdateDraft, onUpdateExisting, onUpdateItemStatus, onRemoveExisting, onSend, onBill, existingOrder } = props;

  const statusColor: Record<string, string> = {
    pending: "bg-warning/15 text-warning-foreground",
    preparing: "bg-primary/10 text-primary",
    ready: "bg-success/15 text-success",
    rejected: "bg-destructive/10 text-destructive",
    served: "bg-muted text-muted-foreground",
  };

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b">
        <div className="text-xs text-muted-foreground">Order</div>
        <div className="flex items-center justify-between">
          <div className="text-base font-semibold">{props.table.name}</div>
          {existingOrder && <div className="text-xs font-mono text-muted-foreground">#{existingOrder.bill_number}</div>}
        </div>
      </div>

      <div className="flex-1 overflow-auto p-3 space-y-2">
        {existing
          .map((i) => (
          <div key={i.id} className={`rounded-xl border p-3 bg-card ${i.status === "served" ? "opacity-50" : ""}`}>
            <div className="flex items-start gap-2">
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm leading-tight truncate">{i.name}</div>
                <div className="flex items-center gap-2 mt-1">
                  <span className={`text-[10px] uppercase font-medium px-1.5 py-0.5 rounded ${statusColor[i.status] ?? ""}`}>
                    {i.status}
                  </span>
                  {i.notes && <span className="text-xs text-muted-foreground truncate">{i.notes}</span>}
                </div>
              </div>
              <div className="text-sm font-semibold">{fmt(Number(i.price) * i.qty, currency)}</div>
            </div>
            {/* Status action buttons — mirrors kitchen controls */}
            {i.status !== "served" && i.status !== "rejected" && (
              <div className="flex items-center gap-1 mt-2 flex-wrap">
                {i.status === "pending" && (
                  <>
                    <StatusBtn label="Prep" onClick={() => onUpdateItemStatus(i.id, "preparing")} color="bg-primary/10 text-primary" />
                    <StatusBtn label="Reject" onClick={() => onUpdateItemStatus(i.id, "rejected")} color="bg-destructive/10 text-destructive" />
                  </>
                )}
                {i.status === "preparing" && (
                  <StatusBtn label="Ready" onClick={() => onUpdateItemStatus(i.id, "ready")} color="bg-success/15 text-success" icon={<Check className="h-3 w-3" />} />
                )}
                {i.status === "ready" && (
                  <StatusBtn label="Served" onClick={() => onUpdateItemStatus(i.id, "served")} color="bg-muted text-muted-foreground" />
                )}
              </div>
            )}
            <div className="flex items-center justify-between mt-2">
              <div className="flex items-center gap-1">
                <button onClick={() => onUpdateExisting(i.id, i.qty - 1)} className="h-8 w-8 grid place-items-center rounded-lg bg-secondary hover:bg-muted">
                  <Minus className="h-3.5 w-3.5" />
                </button>
                <div className="w-8 text-center text-sm font-medium">{i.qty}</div>
                <button onClick={() => onUpdateExisting(i.id, i.qty + 1)} className="h-8 w-8 grid place-items-center rounded-lg bg-secondary hover:bg-muted">
                  <Plus className="h-3.5 w-3.5" />
                </button>
              </div>
              <button onClick={() => onRemoveExisting(i.id)} className="text-destructive p-1.5 rounded-lg hover:bg-destructive/10">
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))}

        {draft.map((d) => (
          <div key={d.item.id} className="rounded-xl border-2 border-dashed border-primary/40 p-3 bg-primary/5">
            <div className="flex items-start gap-2">
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm leading-tight truncate">{d.item.name}</div>
                <div className="text-[10px] uppercase font-medium text-primary mt-1">New</div>
              </div>
              <div className="text-sm font-semibold">{fmt(Number(d.item.sale_price ?? d.item.price) * d.qty, currency)}</div>
            </div>
            <div className="flex items-center justify-between mt-2">
              <div className="flex items-center gap-1">
                <button onClick={() => onUpdateDraft(d.item.id, d.qty - 1)} className="h-8 w-8 grid place-items-center rounded-lg bg-card hover:bg-muted">
                  <Minus className="h-3.5 w-3.5" />
                </button>
                <div className="w-8 text-center text-sm font-medium">{d.qty}</div>
                <button onClick={() => onUpdateDraft(d.item.id, d.qty + 1)} className="h-8 w-8 grid place-items-center rounded-lg bg-card hover:bg-muted">
                  <Plus className="h-3.5 w-3.5" />
                </button>
              </div>
              <button onClick={() => onUpdateDraft(d.item.id, 0)} className="text-destructive p-1.5 rounded-lg hover:bg-destructive/10">
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))}

        {!existing.filter((i) => i.status !== "served").length && !draft.length && (
          <div className="text-center text-sm text-muted-foreground py-12">Tap items to add to the order</div>
        )}
      </div>

      <div className="border-t p-4 space-y-1.5 bg-secondary/30">
        <Row label="Subtotal" value={fmt(subtotal, currency)} />
        <Row label={`Tax (${tax}%)`} value={fmt(taxAmt, currency)} />
        <Row label="Total" value={fmt(total, currency)} bold />
        <div className="grid grid-cols-2 gap-2 pt-3">
          <button
            onClick={onSend}
            disabled={!draft.length}
            className="h-12 rounded-xl bg-primary text-primary-foreground font-medium flex items-center justify-center gap-2 disabled:opacity-40 active:scale-95 transition"
          >
            <Send className="h-4 w-4" /> Send
          </button>
          <button
            onClick={onBill}
            disabled={!existingOrder || !!draft.length}
            className="h-12 rounded-xl bg-foreground text-background font-medium flex items-center justify-center gap-2 disabled:opacity-40 active:scale-95 transition"
          >
            <Receipt className="h-4 w-4" /> Bill
          </button>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className={`flex items-center justify-between text-sm ${bold ? "font-semibold text-base pt-1" : "text-muted-foreground"}`}>
      <span>{label}</span><span className={bold ? "text-foreground" : ""}>{value}</span>
    </div>
  );
}

function MobileCartBar({
  count, total, currency, onSend, onBill, canBill, children,
}: {
  count: number; total: number; currency: string; onSend: () => void; onBill: () => void; canBill: boolean;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <div className="lg:hidden fixed bottom-0 left-0 right-0 border-t surface p-3 flex items-center gap-2 z-20 shadow-pop">
        <button onClick={() => setOpen(true)} className="flex-1 flex items-center justify-between px-3 h-12 rounded-xl bg-secondary">
          <span className="text-sm font-medium">{count} items</span>
          <span className="text-sm font-semibold">{fmt(total, currency)}</span>
        </button>
        <button onClick={onSend} className="h-12 px-4 rounded-xl bg-primary text-primary-foreground font-medium flex items-center gap-2"><Send className="h-4 w-4" /></button>
        <button onClick={onBill} disabled={!canBill} className="h-12 px-4 rounded-xl bg-foreground text-background font-medium disabled:opacity-40 flex items-center gap-2"><Receipt className="h-4 w-4" /></button>
      </div>
      {open && (
        <div className="lg:hidden fixed inset-0 z-40 bg-foreground/40" onClick={() => setOpen(false)}>
          <div className="absolute bottom-0 left-0 right-0 h-[80vh] surface rounded-t-2xl shadow-pop overflow-hidden flex flex-col" onClick={(e) => e.stopPropagation()}>
            {children}
          </div>
        </div>
      )}
    </>
  );
}

/* ---------------- Bill Dialog ---------------- */
function BillDialog({ orderId, tax, currency, onClose }: { orderId: string; tax: number; currency: string; onClose: () => void }) {
  const [order, setOrder] = useState<OrderRow | null>(null);
  const [items, setItems] = useState<OrderItem[]>([]);
  const [restaurant, setRestaurant] = useState<{ name: string; address: string; phone: string }>({ name: "", address: "", phone: "" });
  const [upi, setUpi] = useState<{ upi_id: string; payee_name: string }>({ upi_id: "", payee_name: "" });
  const [printerSettings, setPrinterSettings] = useState<{ paper_size: string }>({ paper_size: "80mm" });
  const [qr, setQr] = useState<string>("");
  const [method, setMethod] = useState<"cash" | "upi" | "card">("upi");
  const [printing, setPrinting] = useState(false);
  const [loadingBill, setLoadingBill] = useState(true);

  // Detect iOS — Web Bluetooth not supported on iPhone/iPad
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);

  useEffect(() => {
    Promise.all([
      supabase.from("orders").select("*").eq("id", orderId).single(),
      supabase.from("order_items").select("*").eq("order_id", orderId),
      supabase.from("settings").select("value").eq("key", "restaurant").maybeSingle(),
      supabase.from("settings").select("value").eq("key", "upi").maybeSingle(),
      supabase.from("settings").select("value").eq("key", "printer").maybeSingle(),
    ]).then(([o, oi, r, u, p]) => {
      setOrder(o.data as OrderRow);
      setItems((oi.data ?? []) as OrderItem[]);
      const rv = (r.data?.value ?? {}) as { name?: string; address?: string; phone?: string };
      setRestaurant({ name: rv.name ?? "[RESTAURANT_NAME]", address: rv.address ?? "[RESTAURANT_ADDRESS]", phone: rv.phone ?? "[PHONE_NUMBER]" });
      const uv = (u.data?.value ?? {}) as { upi_id?: string; payee_name?: string };
      setUpi({ upi_id: uv.upi_id ?? "[YOUR_UPI_ID]", payee_name: uv.payee_name ?? rv.name ?? "Restaurant" });
      const pv = (p.data?.value ?? {}) as { paper_size?: string };
      setPrinterSettings({ paper_size: pv.paper_size ?? "80mm" });
      setLoadingBill(false);
    });
  }, [orderId]);

  useEffect(() => {
    if (!order || !upi.upi_id) return;
    // BUG-001 fix: use toFixed(2) — UPI spec requires 2 decimal places
    const url = `upi://pay?pa=${encodeURIComponent(upi.upi_id)}&pn=${encodeURIComponent(upi.payee_name)}&am=${Number(order.total).toFixed(2)}&cu=INR&tn=${encodeURIComponent("Bill #" + order.bill_number)}`;
    QRCode.toDataURL(url, { margin: 1, width: 220 }).then(setQr).catch(() => setQr(""));
  }, [order, upi]);

  const buildEscPosReceipt = (billItems: OrderItem[]): Uint8Array => {
    const paperSize = printerSettings.paper_size;
    const lineWidth = paperSize === "58mm" ? 32 : 42;
    const cur = "Rs.";

    // Always recalculate totals from items directly — don't trust DB cached values
    const calcSubtotal = billItems.reduce((s, i) => s + Number(i.price) * i.qty, 0);
    const calcTax = (calcSubtotal * tax) / 100;
    const calcTotal = calcSubtotal + calcTax;

    // Use DB values only if they are non-zero, else use calculated
    const subtotal = Number(order!.subtotal) > 0 ? Number(order!.subtotal) : calcSubtotal;
    const taxAmt   = Number(order!.tax) > 0      ? Number(order!.tax)      : calcTax;
    const total    = Number(order!.total) > 0     ? Number(order!.total)    : calcTotal;

    const lines: string[] = [];
    const center = (t: string) => {
      const pad = Math.max(0, Math.floor((lineWidth - t.length) / 2));
      return " ".repeat(pad) + t;
    };
    const divider = "-".repeat(lineWidth);
    const rpad = (l: string, r: string) => {
      const space = Math.max(1, lineWidth - l.length - r.length);
      return l + " ".repeat(space) + r;
    };

    // Header
    lines.push(center(restaurant.name || "ANYA POS"));
    if (restaurant.address) lines.push(center(restaurant.address));
    if (restaurant.phone) lines.push(center("Ph: " + restaurant.phone));
    lines.push(divider);

    // Order info
    const dateStr = new Date(order!.created_at).toLocaleString("en-IN", {
      day: "2-digit", month: "short", year: "numeric",
      hour: "2-digit", minute: "2-digit", hour12: true,
    });
    lines.push(rpad("Bill #" + order!.bill_number, "Table: " + (order!.table_name ?? "-")));
    lines.push(dateStr);
    lines.push(divider);

    // Column headers
    lines.push(rpad("Item", "Amt"));
    lines.push(divider);

    // Items
    if (billItems.length === 0) {
      lines.push("  (no items)");
    } else {
      billItems.forEach((i) => {
        const maxName = lineWidth - 12;
        const name = i.name.length > maxName ? i.name.slice(0, maxName - 1) + "." : i.name;
        const amt = cur + (Number(i.price) * i.qty).toFixed(2);
        lines.push(rpad(name, amt));
        lines.push("  " + i.qty + " x " + cur + Number(i.price).toFixed(2));
      });
    }

    lines.push(divider);

    // Totals — always printed even if items empty
    lines.push(rpad("Subtotal", cur + subtotal.toFixed(2)));
    lines.push(rpad("Tax (" + tax + "%)", cur + taxAmt.toFixed(2)));
    lines.push(divider);
    lines.push(rpad("TOTAL", cur + total.toFixed(2)));
    lines.push(divider);

    // Payment method
    if (order!.payment_method) {
      lines.push(center("Payment: " + order!.payment_method.toUpperCase()));
    }

    // Footer
    lines.push("");
    lines.push(center("Thank you! Visit again."));
    lines.push(""); lines.push(""); lines.push(""); lines.push("");

    // Strip non-ASCII — thermal printers only handle ASCII
    const text = lines.join("\n").replace(/[^\x00-\x7F]/g, "?");
    const encoder = new TextEncoder();
    const textBytes = encoder.encode(text);

    const init = new Uint8Array([0x1b, 0x40]);
    const cut  = new Uint8Array([0x1d, 0x56, 0x42, 0x00]);
    const result = new Uint8Array(init.length + textBytes.length + cut.length);
    result.set(init, 0);
    result.set(textBytes, init.length);
    result.set(cut, init.length + textBytes.length);
    return result;
  };

  const printViaBluetooth = async () => {
    if (!order) return;
    if (!("bluetooth" in navigator)) {
      toast.error("Bluetooth not supported in this browser. Use Chrome on Android.");
      return;
    }
    setPrinting(true);
    try {
      // Try common BLE thermal printer service UUIDs
      const serviceUUIDs = [
        "000018f0-0000-1000-8000-00805f9b34fb", // Common ESC/POS BLE
        "e7810a71-73ae-499d-8c15-faa9aef0c3f2", // Rongta / Xprinter
        "49535343-fe7d-4ae5-8fa9-9fafd205e455", // iDPRT / generic
      ];
      const device = await (navigator as any).bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: serviceUUIDs,
      });
      const server = await device.gatt.connect();

      // Try each service UUID until one works
      let characteristic: any = null;
      for (const sUUID of serviceUUIDs) {
        try {
          const service = await server.getPrimaryService(sUUID);
          const chars = await service.getCharacteristics();
          // Find a writable characteristic
          characteristic = chars.find((c: any) =>
            c.properties.write || c.properties.writeWithoutResponse
          );
          if (characteristic) break;
        } catch { /* try next */ }
      }

      if (!characteristic) {
        toast.error("Printer connected but no writable channel found. Try a different printer.");
        await device.gatt.disconnect();
        setPrinting(false);
        return;
      }

      const billItems = items.filter((i) => i.status !== "rejected");
      const data = buildEscPosReceipt(billItems);

      // Send in 512-byte chunks
      const chunkSize = 512;
      for (let i = 0; i < data.length; i += chunkSize) {
        const chunk = data.slice(i, i + chunkSize);
        if (characteristic.properties.writeWithoutResponse) {
          await characteristic.writeValueWithoutResponse(chunk);
        } else {
          await characteristic.writeValue(chunk);
        }
      }

      await device.gatt.disconnect();
      toast.success("Printed successfully!");
    } catch (e: any) {
      if (e?.name === "NotFoundError") {
        toast.info("No printer selected");
      } else {
        toast.error("Print failed: " + (e?.message ?? "Unknown error"));
      }
    }
    setPrinting(false);
  };

  const printViaBrowser = () => {
    // Set page size dynamically based on printer settings
    const style = document.createElement("style");
    style.id = "thermal-print-style";
    style.innerHTML = `
      @media print {
        @page { size: ${printerSettings.paper_size} auto; margin: 2mm; }
        body * { visibility: hidden; }
        #print-area, #print-area * { visibility: visible; }
        #print-area { position: absolute; left: 0; top: 0; width: 100%; font-size: 11px; font-family: monospace; }
      }
    `;
    document.head.appendChild(style);
    window.print();
    setTimeout(() => document.getElementById("thermal-print-style")?.remove(), 1000);
  };

  const settle = async () => {
    if (!order) return;
    // BUG-005 fix: only update if still open — prevents double-billing race condition
    const { count } = await supabase
      .from("orders")
      .select("id", { count: "exact", head: true })
      .eq("id", order.id)
      .eq("status", "open");
    if (!count) return toast.error("Order already settled");

    await supabase
      .from("orders")
      .update({ status: "billed", billed_at: new Date().toISOString(), payment_method: method, payment_status: "paid" })
      .eq("id", order.id)
      .eq("status", "open"); // safe no-op if already billed
    // Mark non-rejected items served
    await supabase.from("order_items").update({ status: "served" }).eq("order_id", order.id).neq("status", "rejected");
    toast.success("Bill settled");
    setTimeout(() => onClose(), 300);
  };

  if (!order) return null;
  const billItems = items.filter((i) => i.status !== "rejected");

  return (
    <div className="fixed inset-0 z-50 bg-foreground/50 grid place-items-center p-4" onClick={onClose}>
      <div className="surface rounded-2xl shadow-pop max-w-md w-full max-h-[90vh] overflow-auto" onClick={(e) => e.stopPropagation()}>
        {/* Visible bill */}
        <div id="print-area" className="p-6 space-y-3">
          <div className="text-center">
            <div className="text-xl font-bold">{restaurant.name}</div>
            <div className="text-xs text-muted-foreground">{restaurant.address}</div>
            <div className="text-xs text-muted-foreground">{restaurant.phone}</div>
          </div>
          <div className="border-t border-dashed pt-2 text-xs grid grid-cols-2 gap-1">
            <div>Bill #: <b>{order.bill_number}</b></div>
            <div className="text-right">Table: <b>{order.table_name}</b></div>
            <div className="col-span-2">Date: {new Date(order.created_at).toLocaleString()}</div>
          </div>
          <div className="border-t border-dashed pt-2 space-y-1">
            <div className="grid grid-cols-12 text-xs font-semibold text-muted-foreground">
              <div className="col-span-6">Item</div>
              <div className="col-span-2 text-center">Qty</div>
              <div className="col-span-2 text-right">Rate</div>
              <div className="col-span-2 text-right">Amt</div>
            </div>
            {billItems.map((i) => (
              <div key={i.id} className="grid grid-cols-12 text-xs">
                <div className="col-span-6 truncate">{i.name}</div>
                <div className="col-span-2 text-center">{i.qty}</div>
                <div className="col-span-2 text-right">{Number(i.price).toFixed(2)}</div>
                <div className="col-span-2 text-right">{(Number(i.price) * i.qty).toFixed(2)}</div>
              </div>
            ))}
          </div>
          <div className="border-t border-dashed pt-2 space-y-1 text-xs">
            <Row label="Subtotal" value={fmt(order.subtotal, currency)} />
            <Row label={`Tax (${tax}%)`} value={fmt(order.tax, currency)} />
            <Row label="TOTAL" value={fmt(order.total, currency)} bold />
          </div>
          <div className="text-center text-xs text-muted-foreground border-t border-dashed pt-2">
            Thank you! Visit again.
          </div>
        </div>

        {/* Controls (hidden in print) */}
        <div className="border-t p-4 space-y-3 print:hidden">
          {qr && (
            <div className="flex items-center gap-3 p-3 rounded-xl bg-secondary">
              <img src={qr} alt="UPI QR" className="h-24 w-24 rounded-lg bg-white p-1" />
              <div className="text-xs">
                <div className="font-semibold">Scan to pay</div>
                <div className="text-muted-foreground">{upi.upi_id}</div>
                <div className="font-semibold mt-1">{fmt(order.total, currency)}</div>
              </div>
            </div>
          )}
          <div>
            <div className="text-xs font-medium text-muted-foreground mb-2">Payment method</div>
            <div className="grid grid-cols-3 gap-2">
              {(["cash", "upi", "card"] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => setMethod(m)}
                  className={`h-11 rounded-xl border-2 text-sm font-medium uppercase ${
                    method === m ? "border-primary bg-primary/5 text-primary" : "border-border bg-card"
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 pt-1">
            {!isIOS ? (
              <button
                onClick={printViaBluetooth}
                disabled={printing || loadingBill}
                className="h-12 rounded-xl bg-secondary font-medium flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {printing ? "Printing…" : loadingBill ? "Loading…" : "🖨 Bluetooth"}
              </button>
            ) : (
              <button
                onClick={printViaBrowser}
                disabled={loadingBill}
                className="h-12 rounded-xl bg-secondary font-medium flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loadingBill ? "Loading…" : "🖨 Print (WiFi)"}
              </button>
            )}
            {!isIOS && (
              <button onClick={printViaBrowser} disabled={loadingBill} className="h-12 rounded-xl bg-muted font-medium text-sm disabled:opacity-50">
                WiFi Print
              </button>
            )}
            <button onClick={settle} className={`h-12 rounded-xl bg-success text-success-foreground font-semibold ${!isIOS ? "col-span-2" : ""}`}>
              Mark Paid
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
